
var cityCollegeDetails = [{ cityName: " Bangalore", cityId: "bgl", collegeName: "New Horizon", collegeID: "college1",course: "Computer Science" },
{ cityName: " Bangalore", cityId: "city1", collegeName: "XYZ", collegeID: "college2",course: "Computer Science" }
];


module.exports = {

    cityCollegeDetails
  
};