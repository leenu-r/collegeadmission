
var cityCollegeDetails = [{ cityName: " Bangalore", cityId: "bgl", collegeName: "New Horizon College of Engineering", collegeID: "NHS",collegeDesc: "New Horizon College of Engineering is an Autonomous college, Permanently Affiliated to Visvesvaraya Technological University, Approved by the All India Council for Technical Education & University Grants Commission. It is Accredited by NAAC with 'A' grade & NBA ", courses :  "Computer Science" },
{ cityName: " Bangalore", cityId: "bgl", collegeName: "Bangalore University", collegeID: "BU", collegeDesc:"Ramaiah Institute of Technology, formerly known as M.S. Ramaiah Institute of Technology, is an autonomous private engineering college located in Bangalore in the Indian state of Karnataka. Established in 1962, the college is affiliated to Visvesvaraya Technological University" ,courses: "Chemical Engineering" },
{ cityName: " Bangalore", cityId: "bgl", collegeName: "Indian Institute of Science", collegeID: "IISC",collegeDesc:"The Indian Institute of Science is a public, deemed, research university for higher education and research in science, engineering, design, and management. It is located in Bangalore, in the Indian state of Karnataka.", course: "Computer Science", courses:"Electronics"},
{cityName: " Bangalore", cityId: "bgl", collegeName: "Ramaiah Institute of Technology", collegeID: "RIT", collegeDesc:"Ramaiah Institute of Technology, formerly known as M.S. Ramaiah Institute of Technology, is an autonomous private engineering college located in Bangalore in the Indian state of Karnataka. Established in 1962, the college is affiliated to Visvesvaraya Technological University", courses: "Mechanical" }
  
];


module.exports = {

    cityCollegeDetails
  
};