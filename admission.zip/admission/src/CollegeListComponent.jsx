import React from 'react'

import { cityCollegeDetails } from "./staticfiles/staticdata.jsx";
const CollegeListComponent = () => (
  <table>
    <thead>
      <tr>

         
         <th>City</th>
    
        <th>College Name</th>

        <th>Course</th>
        
        
      </tr>
    </thead>
    <tbody>
      {cityCollegeDetails.length > 0 ? (
        cityCollegeDetails.map((college) => (
          <tr key={college.collegeID}>
            <td>{college.cityName}</td>
            <td>{college.collegeName}</td>
            <td>{college.course}</td>
           
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={3}>No Colleges</td>
        </tr>
      )}
    </tbody>
  </table>
)



export default CollegeListComponent;