import React, {Component} from 'react'
import CollegeListComponent from './CollegeListComponent'

class App extends Component {
  render() {
    return (
      <div className="container">
        <CollegeListComponent />
      </div>
    )
  }
}

export default App